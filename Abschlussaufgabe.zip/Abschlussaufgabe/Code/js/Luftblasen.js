var Endabgabe;
(function (Endabgabe) {
    class Luftblasen {
        constructor() {
        }
        update() { }
        ;
    }
    Endabgabe.Luftblasen = Luftblasen;
})(Endabgabe || (Endabgabe = {}));
//# sourceMappingURL=Luftblasen.js.map