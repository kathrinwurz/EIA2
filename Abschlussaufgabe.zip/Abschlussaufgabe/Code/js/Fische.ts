namespace Endabgabe {

    export class Fische {

        groesse: number;
        x: number;
        y: number;
        dx: number;
        dy: number;

        constructor() {

        }

        update() { };


    }
}