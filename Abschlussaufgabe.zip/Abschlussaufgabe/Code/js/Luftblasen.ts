namespace Endabgabe {

    export class Luftblasen {

        x: number;
        y: number;
        dx: number;
        dy: number;

        constructor() {

        }

        update() { };



    }
}