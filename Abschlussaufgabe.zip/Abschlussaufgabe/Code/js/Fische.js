var Endabgabe;
(function (Endabgabe) {
    class Fische {
        constructor() {
        }
        update() { }
        ;
    }
    Endabgabe.Fische = Fische;
})(Endabgabe || (Endabgabe = {}));
//# sourceMappingURL=Fische.js.map