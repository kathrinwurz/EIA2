/*Abschlussaufgabe
Name: Kathrin Wurz
Matrikel: 260742
Datum: .07.2019
Hiermit versichere ich, dass ich diesen Code selbst geschrieben habe. 
Er wurde nicht kopiert und auch nicht diktiert.*/



interface Bestenliste {
    [key: string]: string;
}

interface Spieler {
    name: string;
    punktestand: number;
}
