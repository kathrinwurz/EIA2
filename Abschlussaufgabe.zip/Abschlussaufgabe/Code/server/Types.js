/*Abschlussaufgabe
Name: Kathrin Wurz
Matrikel: 260742
Datum: .07.2019
Hiermit versichere ich, dass ich diesen Code selbst geschrieben habe.
Er wurde nicht kopiert und auch nicht diktiert.*/
//# sourceMappingURL=Types.js.map